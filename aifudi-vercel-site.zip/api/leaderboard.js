
import { kv } from '@vercel/kv'

export default async function handler(req, res){
  try{
    // get top 50 (highest scores)
    const arr = await kv.zrevrange('aifudi:lb', 0, 49, { withScores: false })
    const data = []
    for(const member of arr){
      try{
        const obj = JSON.parse(member)
        data.push({ ig: obj.ig, score: obj.score, ts: obj.ts })
      }catch{}
    }
    return res.json({ ok:true, data })
  }catch(e){
    console.error(e)
    return res.status(500).json({ ok:false, error:'server', data: [] })
  }
}
