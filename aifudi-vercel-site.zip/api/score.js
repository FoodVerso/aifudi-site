
import crypto from 'node:crypto'
import { kv } from '@vercel/kv'

function hmacValid({ig, score, ts, sig}){
  const secret = process.env.LEADERBOARD_SECRET
  if(!secret) return true // allow if not set (dev)
  if(!ig || !score || !ts || !sig) return false
  const msg = `${ig}:${score}:${ts}`
  const want = crypto.createHmac('sha256', secret).update(msg).digest('hex')
  return crypto.timingSafeEqual(Buffer.from(want), Buffer.from(sig))
}

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).json({ok:false, error:'method'})
  try{
    const { ig, wa, score, ts, sig } = req.body || {}
    const cleanIg = String(ig||'').trim().slice(0,32)
    const cleanWa = String(wa||'').trim().slice(0,32)
    const nscore = Math.max(0, parseInt(score||0,10))
    const nts = Math.max(0, parseInt(ts||Date.now(),10))

    if(!cleanIg || !nscore) return res.status(400).json({ok:false, error:'bad_input'})
    if(!hmacValid({ig:cleanIg, score:nscore, ts:nts, sig})) return res.status(401).json({ok:false, error:'bad_sig'})

    // member json (do not expose wa in leaderboard)
    const member = JSON.stringify({ ig: cleanIg, wa: cleanWa, score: nscore, ts: nts })

    // Use a composite score so ties keep earlier one first (score*1e6 + clamp ts)
    const zscore = (nscore * 1_000_000) + Math.min(999_999, Math.floor((nts/1000)%1_000_000))
    await kv.zadd('aifudi:lb', { score: zscore, member })
    // Trim to top 200 to keep storage bounded
    await kv.zremrangebyrank('aifudi:lb', 0, -201)

    return res.json({ok:true})
  }catch(e){
    console.error(e)
    return res.status(500).json({ok:false, error:'server'})
  }
}
